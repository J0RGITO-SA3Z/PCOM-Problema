Problema: "El dilema de Miguel"
Autores: Jorge Sáez Salto y Miguel Xuclá Herrero

En la carpeta "Ficheros de casos" se encuentran varios txt:
	
	- "casos_enunciado.txt" contiene los casos mostrados en el enunciado.
	- "casos_especiales.txt" contiene los casos especiales escritos manualmente.
	- "salida_casos_especiales.txt" contiene el output esperado para los casos especiales descritos.
	- "ejemplo_aleatorios.txt" contiene una muestra de 2 casos aleatorios, uno pequeño y otro grande.
	- "ejemplo_exhaustivos.txt" contiene los casos exhaustivos descritos por el generador, fijando tanto la K como la Z a distintos valores y generando 10 casos aleatorios para el resto de valores.
	- "ejemplo_grandes.txt" contiene los 2 casos grandes descritos por el generador, uno con K = 0 y otro con K = al número de aristas.


En los casos especiales se prueba (en orden): 

	- Los dos primeros casos utilizan la máxima capacidad, en uno se borra la arista y en el otro no. Se prueba que el borrado de aristas funciona de la forma más sencilla posible.
	- Los dos siguientes comprueban que se borra la arista de mayor capacidad y que se hace uso de un grafo dirigido.
	- El siguiente comprueba que el algoritmo permite que haya autoaristas y ciclos sin alterar su resultado.
	- El siguiente es un caso en el que se sabotean todas las aristas, comprobando que el flujo sea 0 si todas las conexiones son saboteadas.
	- El siguiente comprueba que, cuando haya dos aristas con la capacidad máxima, se borre la arista que haya entrado primero.


En los casos grandes generamos tantas aristas y vértices como nos permite el máximo establecido en el enunciado y diferenciamos dos casos: K = 0 y K = M. Hacemos esto para comprobar los dos puntos críticos posibles del algoritmo. El caso de K = 0 trata de colocar tantas aristas como sea posible, para detectar si el algoritmo que calcula el max flow debe dar TLE o no. Por otro lado, el caso de K = M comprueba que la eliminación o sabotage de aristas sea eficiente.


En la carpeta "Generadores de casos" se encuentran 3 generadores: para los casos aleatorios (que genera 5000 casos, 2500 "pequeños" y 2500 grandes), los casos exhaustivos y los casos grandes.


En la carpeta "Solución comprobadora" se encuentra la solución oficial pero comprobando que los datos de entrada estén dentro de los límites establecidos por el enunciado.


En la carpeta "Soluciones aceptadas" se encuentran tanto la solución "oficial" hecha por Jorge Sáez Salto, como otra solución hecha por Miguel Xuclá Herrero. Ambas siguen una implementación similar, saboteando las aristas gracias a una cola de prioridad (creando un operador de orden especial) y haciendo uso del algoritmo de Edmonds-Karp para calcular el max flow en el grafo resultante. La diferencia entre las dos implementaciones es que la de Jorge primero construye el grafo y luego las sabotea poniendo su capacidad a 0, mientras que la de Miguel primero sabotea las aristas que deba y después construye el grafo con las restantes.

En la carpeta "Soluciones malas" se encuentra una única implementación. La verdad es que no se nos ha ocurrido ninguna forma de resolver el algoritmo de forma ineficiente, así que nos pusimos a investigar y a usar otras herramientas, entre ellas ChatGPT. Esperamos que no sea un inconveniente ya que solo la hemos usado en esto, pero es cierto que esta implementación ni la hemos modificado más allá de adaptarla a la plantilla para hacer pruebas. Le pedimos que nos hiciera una implementación usando Ford-Fulkerson, que por lo que nos ha parecido es similar al Edmonds-Karp pero la principal diferencia es que usa DFS en vez de BFS, siendo mucho más ineficiente. Comprobamos que fuera una solución válida y que tardara bastante más que nuestras implementaciones.